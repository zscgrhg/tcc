CruiseControl Binary Release
Release: 2.8.4

This binary release is a trimmed down version of the full CruiseControl release.
It is fully functional and intended to work with a sample Subversion project "out of
the box".

See docs/gettingstartedbindist.html for complete documentation.